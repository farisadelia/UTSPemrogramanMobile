package com.example.utsadelia

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Adapter (private val context: Context, private val kucing: List<Kucing>, val listener: (Kucing) -> Unit)
    : RecyclerView.Adapter<Adapter.KucingViewHolder>(){
    class KucingViewHolder(view: View): RecyclerView.ViewHolder(view) {

        val imgkucing = view.findViewById<ImageView>(R.id.img_item_photo)
        val namekucing = view.findViewById<TextView>(R.id.tv_item_name)
        val desckucing = view.findViewById<TextView>(R.id.tv_item_description)

        fun bindView(kucing: Kucing, listener: (Kucing) -> Unit){
            imgkucing.setImageResource(kucing.imgkucing)
            namekucing.text = kucing.namekucing
            desckucing.text = kucing.desckucing
            itemView.setOnClickListener{
                (listener(kucing))
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): KucingViewHolder {
        return KucingViewHolder(
            LayoutInflater.from(context).inflate(R.layout.item_kucing, parent, false)
        )
    }

    override fun onBindViewHolder(holder: KucingViewHolder, position: Int) {
        holder.bindView(kucing[position], listener)
    }

    override fun getItemCount(): Int = kucing.size

}
