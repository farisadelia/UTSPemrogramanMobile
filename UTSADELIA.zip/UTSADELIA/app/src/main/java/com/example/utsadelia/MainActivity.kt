package com.example.utsadelia

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.utsadelia.R.id.kucing

class MainActivity : AppCompatActivity() {

    companion object{
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val kucingList = listOf<Kucing>(
            Kucing(
                R.drawable.kucingabyssinia,
                namekucing = "Kucing Abyssinia",
                desckucing = "Jenis kucing ini sangat cantik dan populer karena mereka jenius"
 ),
            Kucing(
                R.drawable.kucingbirman,
                namekucing =  "Kucing Birman",
                desckucing = "Jenis kucing Birman mudah dikenali dari mata birunya yang khas serta hidung cokelatnya yang manis"
),
            Kucing(
                R.drawable.kucingbritish,
                namekucing =  "Kucing British",
                desckucing = "Kucing British Shorthairs bisa dibilang sebuah kesempurnaan karena memiliki bulu yang halus"
 ),
            Kucing(
                R.drawable.kucingpersia,
                namekucing =  "Kucing Persia",
                desckucing = "Kucing Persia sangat lucu dan terlihat seperti boneka. Ras kucing ini paling populer"
 ),
            Kucing(
                R.drawable.kucingscottish,
                namekucing =  "Kucing Scottish",
                desckucing = "Kamu mungkin sudah akrab dengan ras kucing ini yang dikenal sebagai lipatan Skotlandia"
),
            Kucing(
                R.drawable.kucingshorthairs,
                namekucing =  "Kucing Shorthairs",
                desckucing = "Kucing jenis American Shorthairs ini memiliki masa hidup yang lama."
),
            Kucing(
                R.drawable.kucingsphynx,
                namekucing = "Kucing Sphynx",
                desckucing = "Kucing Sphynx termasuk jenis kucing tidak berbulu.",
            ),
        )
        val recyclerView = findViewById<RecyclerView>(kucing)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = Adapter(this, kucingList){
            val intent = Intent (this, Detail::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)
        }
    }
}

private fun Intent.putExtra(intentParcelable: String, it: Kucing) {
    TODO("Not yet implemented")
}
