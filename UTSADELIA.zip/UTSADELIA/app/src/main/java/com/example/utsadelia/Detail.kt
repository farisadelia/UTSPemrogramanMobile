package com.example.utsadelia

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Detail : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_kucing)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val kucing = intent.getParcelableExtra<Kucing>(MainActivity.INTENT_PARCELABLE)

        val imgkucing = findViewById<ImageView>(R.id.img_item_photo)
        val namekucing = findViewById<TextView>(R.id.tv_item_name)
        val desckucing = findViewById<TextView>(R.id.tv_item_description)


        imgkucing.setImageResource(kucing?.imgkucing!!)
        namekucing.text = kucing.namekucing
        desckucing.text = kucing.desckucing

    }

    override fun onSupportNavigateUp(): Boolean {

        onBackPressed()
        return true
    }
}