package com.example.utsadelia

import android.os.Parcelable

class Kucing (
    val imgkucing: Int,
    val namekucing: String,
    val desckucing: String
    )